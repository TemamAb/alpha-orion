
import { useState, useEffect } from 'react';
import { Microservice, Opportunity, Strategy, PnlChartData, ServiceStatus } from '../types';
import { SERVICE_LIST, REGIONS } from '../constants';

const random = (min: number, max: number) => Math.random() * (max - min) + min;
const randomInt = (min: number, max: number) => Math.floor(random(min, max));
const randomElement = <T,>(arr: readonly T[]): T => arr[Math.floor(Math.random() * arr.length)];

const generateService = (name: string): Microservice => ({
  id: name,
  name,
  region: randomElement(REGIONS),
  status: randomElement(['online', 'online', 'online', 'degraded', 'offline']),
  cpuUsage: random(5, 80),
  memoryUsage: random(10, 90),
  lastLog: `[INFO] ${new Date().toISOString()} - Operation successful.`,
});

const generateOpportunity = (id: number): Opportunity => ({
  id: `opp-${id}-${Date.now()}`,
  assets: ['ETH', 'USDC'],
  exchanges: ['Uniswap', 'Sushiswap'],
  potentialProfit: random(50, 1500),
  riskLevel: randomElement(['Low', 'Medium', 'High']),
  timestamp: Date.now(),
});

const generateStrategy = (id: number): Strategy => ({
    id: `strat-${id}`,
    name: `Momentum Strategy ${id}`,
    description: 'Trades based on recent price movements.',
    isActive: Math.random() > 0.3,
    pnl: random(-5000, 25000),
    winRate: random(45, 75),
});

const generatePnlData = (): PnlChartData[] => {
    let pnl = 10000;
    return Array.from({ length: 30 }, (_, i) => {
        const date = new Date();
        date.setDate(date.getDate() - (29 - i));
        pnl += random(-2000, 3500);
        return {
            time: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            pnl: pnl,
        };
    });
};


export const useMockData = () => {
  const [services, setServices] = useState<Microservice[]>(() => SERVICE_LIST.map(generateService));
  const [opportunities, setOpportunities] = useState<Opportunity[]>(() => Array.from({ length: 15 }, (_, i) => generateOpportunity(i)));
  const [strategies, setStrategies] = useState<Strategy[]>(() => Array.from({ length: 5 }, (_, i) => generateStrategy(i)));
  const [pnlData, setPnlData] = useState<PnlChartData[]>(generatePnlData);
  const [totalPnl, setTotalPnl] = useState<number>(125430.50);
  const [totalTrades, setTotalTrades] = useState<number>(8432);

  useEffect(() => {
    const serviceInterval = setInterval(() => {
      setServices(prev => prev.map(s => ({
        ...s,
        status: Math.random() < 0.05 ? randomElement(['degraded', 'offline']) : 'online',
        cpuUsage: Math.max(5, Math.min(95, s.cpuUsage + random(-5, 5))),
        memoryUsage: Math.max(10, Math.min(95, s.memoryUsage + random(-5, 5))),
      })));
    }, 5000);

    const opportunityInterval = setInterval(() => {
      setOpportunities(prev => [generateOpportunity(prev.length + 1), ...prev.slice(0, 49)]);
      setTotalPnl(pnl => pnl + random(50, 200));
      setTotalTrades(trades => trades + 1);
    }, 3000);
    
    const pnlInterval = setInterval(() => {
        setPnlData(prev => {
            const lastPoint = prev[prev.length - 1];
            const newPnl = lastPoint.pnl + random(-500, 800);
            const newPoint = {
                time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
                pnl: newPnl
            };
            const newArr = [...prev.slice(1), newPoint];
            return newArr;
        });
    }, 10000);

    return () => {
      clearInterval(serviceInterval);
      clearInterval(opportunityInterval);
      clearInterval(pnlInterval);
    };
  }, []);

  return { services, opportunities, strategies, pnlData, totalPnl, totalTrades };
};
